(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/07552_@supabase_node-fetch_browser_3771a607.js",
  "static/chunks/729cd_@supabase_auth-js_dist_module_c44f0d8b._.js",
  "static/chunks/78375_tailwind-merge_dist_bundle-mjs_mjs_46ec1965._.js",
  "static/chunks/node_modules__pnpm_c33c87c3._.js",
  "static/chunks/_52f7f932._.js"
],
    source: "dynamic"
});
