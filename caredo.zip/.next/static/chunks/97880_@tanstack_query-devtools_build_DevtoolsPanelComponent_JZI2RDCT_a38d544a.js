(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/97880_@tanstack_query-devtools_build_2d949b41._.js"
],
    source: "dynamic"
});
