(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_7da70081._.js",
  "static/chunks/components_ce6e53c4._.js"
],
    source: "dynamic"
});
