(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_32ac8b6b._.js",
  "static/chunks/_319ef8bc._.js"
],
    source: "dynamic"
});
