(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/07552_@supabase_node-fetch_browser_3a4f54cb.js",
  "static/chunks/node_modules__pnpm_cd99ce8d._.js",
  "static/chunks/_96865ef0._.js"
],
    source: "dynamic"
});
