(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/97880_@tanstack_query-devtools_build_3b1efae6._.js",
  "static/chunks/node_modules__pnpm_1a761ff6._.js",
  "static/chunks/app_providers_tsx_4759cad9._.js",
  "static/chunks/[root-of-the-server]__4349a9b2._.css"
],
    source: "dynamic"
});
