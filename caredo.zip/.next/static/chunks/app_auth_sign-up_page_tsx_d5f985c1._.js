(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/07552_@supabase_node-fetch_browser_1fe6f62c.js",
  "static/chunks/node_modules__pnpm_cd99ce8d._.js",
  "static/chunks/_dd320882._.js"
],
    source: "dynamic"
});
