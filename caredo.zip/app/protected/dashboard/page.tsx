import DoctorDashboard from './../../../components/doctor-dashboard';



export default function Home() {
  return (
    <main>
      <DoctorDashboard />
    </main>
  );
}
