"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Menu } from "lucide-react";
import { useRouter } from "next/navigation"; // ✅ App Router-compatible

const benefitsList = [
  { text: "2 month free testing plan", isBold: true },
  { text: "₹0/day", isBold: true },
  { text: "Access all premium features", isBold: false },
  { text: "0% commission on patients", isBold: false },
  {
    text: "Unlimited bookings, patients & doctors",
    isBold: false,
    hasItalic: true,
  },
];

export default function DoctorDashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const router = useRouter();

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  const handleClick = () => {
    router.push("/protected/doctorlogin");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-white to-white flex flex-col">
      <header className="flex items-center justify-between w-full p-4 md:px-8 lg:px-12 border-b border-gray-200">
        <button
          onClick={toggleMenu}
          aria-label="Open menu"
          className="text-black text-2xl md:text-3xl"
        >
          <Menu className="w-7 h-7 md:w-8 md:h-8" />
        </button>

        <div className="font-normal text-3xl tracking-[0.30px] leading-[27.0px] md:text-4xl md:leading-[36px] lg:text-4xl lg:leading-[45px]">
          <span className="text-black tracking-[0.09px]">Care</span>
          <span className="text-[#2ec4b6] tracking-[0.09px]">do</span>
        </div>

        <div className="flex flex-col items-end">
          <span className="font-bold text-[#ffbb00] text-[13px] tracking-[0.13px] leading-[11.7px] md:text-base md:leading-[14px]">
            150+
          </span>
          <span className="font-normal text-[#807d7d] text-[11px] tracking-[0.11px] leading-[9.9px] md:text-sm md:leading-[12px]">
            doctors joined
          </span>
        </div>
      </header>

      {isMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={closeMenu}
        />
      )}

      <div
        className={`fixed top-0 left-0 h-full bg-white shadow-lg z-50 transform transition-transform duration-300 ${
          isMenuOpen ? "translate-x-0" : "-translate-x-full"
        } w-64 md:w-80`}
      >
        <div className="p-6 flex flex-col h-full relative">
          <div className="flex items-center space-x-1 text-lg font-semibold mb-8 md:text-xl">
            <span>Care</span>
            <span className="text-[#2ec4b6]">do</span>
          </div>
          <button
            onClick={closeMenu}
            className="absolute top-4 right-4 text-gray-700 text-2xl md:text-3xl"
          >
            &times;
          </button>
          <nav className="space-y-4 flex-grow text-lg md:text-xl">
            {["My Profile", "Plans & Pricing", "Terms & Condition", "Contact Us", "Give Feedback"].map((item, idx) => (
              <a
                key={idx}
                href="#"
                className="block text-gray-800 hover:text-[#2ec4b6] font-medium py-2 transition-colors duration-200"
                onClick={closeMenu}
              >
                {item}
              </a>
            ))}
          </nav>
          <Button
            className="mt-auto w-full bg-gray-800 text-white rounded-full py-2 text-sm font-semibold hover:bg-gray-700 transition-colors duration-200 md:text-base md:py-3"
            onClick={closeMenu}
          >
            Login
          </Button>
        </div>
      </div>

      <main className="flex flex-1 flex-col md:flex-row justify-center items-center py-8 px-4 md:py-12 md:px-8">
        <div className="flex flex-col justify-between h-full max-w-md w-full md:mr-12 text-center md:text-left items-center md:items-start">
          <div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Join fast, Patients are waiting for you...
            </h1>
            <div className="mt-8 space-y-2">
              <div className="font-extrabold text-xl sm:text-2xl text-[#ff9400]">{'"'}One INDIA,</div>
              <div className="font-extrabold text-xl sm:text-2xl text-black">All Doctors,</div>
              <div className="font-extrabold text-xl sm:text-2xl text-[#09bbaa]">One Caredo{'"'}</div>
            </div>
          </div>
          <div className="mt-8 sm:mt-12">
            <p className="italic text-gray-600 text-base">
              "Be the part of this mission to save time and life of every Indians"
            </p>
          </div>
        </div>

        <div className="relative max-w-lg w-full mt-12 md:mt-0 flex justify-center items-center">
          <div className="hidden md:block absolute -top-10 -left-10 w-full h-[420px] rounded-3xl bg-[#ffbb00] opacity-80 blur-xl z-0" />
          <Card className="relative z-10 rounded-2xl border border-gray-300 shadow-xl bg-white w-full max-w-md mx-auto">
            <CardContent className="p-6 sm:p-8 flex flex-col h-full">
              <div className="flex justify-between items-center mb-4">
                <div className="font-bold text-[#424242] text-lg sm:text-xl">2 MONTHS</div>
                <div className="font-semibold text-[#14d100] text-xl sm:text-2xl">*FREE</div>
              </div>
              <ul className="mt-4 mb-6 space-y-3">
                {benefitsList.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 mt-2 mr-3 bg-black rounded-full flex-shrink-0" />
                    <span className={`${benefit.isBold ? "font-semibold" : "font-normal"} text-gray-800 text-base`}>
                      {benefit.text}
                      {benefit.hasItalic && (
                        <span className="italic text-sm text-gray-500">
                          {' '}(within the same hospital)
                        </span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
              <Separator className="my-2" />
              <div className="italic text-gray-700 text-sm mb-6">*Join Caredo for Free</div>
              <Button
                className="w-full h-12 bg-[#424242] rounded-2xl text-lg font-semibold hover:bg-[#323232]"
                onClick={handleClick}
              >
                Register Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
