// app/layout.tsx
import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import Providers from "@/app/providers"; // Assuming this handles other client-side providers
import { ThemeProviderWrapper } from "./theme-provider-wrapper"; // Import the new wrapper

const defaultUrl = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(defaultUrl),
  title: "Next.js and Supabase Starter Kit",
  description: "The fastest way to build apps with Next.js and Supabase",
};

const geistSans = Geist({
  variable: "--font-geist-sans",
  display: "swap",
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <body className={`${geistSans.className} antialiased`} suppressHydrationWarning={true}> 
        <ThemeProviderWrapper> 
          <Providers>{children}</Providers>
        </ThemeProviderWrapper>
      </body>
    </html>
  );
}